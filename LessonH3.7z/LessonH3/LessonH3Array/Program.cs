﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LessonH3Array
{
    class Program
    {
        static void Main(string[] args)
        {


        //  length
        Console.WriteLine("Please enter array length : ");
            string inputLenght = Console.ReadLine();
            int num;

            while (!int.TryParse(inputLenght, out num))
            {
                Console.WriteLine("Invalid. Please, enter a number.");
                inputLenght = Console.ReadLine();
            }
            int ar= Convert.ToInt32(inputLenght);
            int[] arr = new int[ar];

        //numbers
            var index = 0;
            while (index<arr.Length)
            {
                Console.WriteLine("Enter a number:");
                var input = Console.ReadLine();
                var number = 0;
                if (!int.TryParse(input, out number))
                {
                    Console.WriteLine("Invalid. Please, enter array number range.");
                }
                else
                {
                    arr[index] = number;
                    index++;
                }
            }

            // sorting asc
            int temp;
            for (int i =0; i < arr.Length-1 ; i++)
            {
                for (int j = i + 0; j < arr.Length; j++)
                {
                    if (arr[i] > arr[j])
                    {
                        temp = arr[i];
                        arr[i] =arr[j];
                        arr[j] = temp;
                    }
                }
            }

            Console.Write("\nElements in array are: ");
            for (int i=0; i < arr.Length; i++)
            {
                Console.Write("{0}  ", arr[i]);
            }
            Console.Write("\n");
            Console.ReadLine();
        }
        
    }
 }

