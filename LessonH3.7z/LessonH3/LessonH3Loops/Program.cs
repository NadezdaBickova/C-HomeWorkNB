﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LessonH3Loops
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j, midl, rows, k, num = 1;

            Console.Write("input number of rows : ");
            string input = Console.ReadLine();
            while (!int.TryParse(input, out num))
            {
                Console.WriteLine("Invalid. Please, enter a number.");
                input = Console.ReadLine();
            }

            rows = Convert.ToInt32(input);
            midl = rows;
            for (i = 1; i <= rows; i++)
            {
                for (k = midl; k >= 1; k--)
                {
                    Console.Write(" ");
                }
                for (j = 1; j <= i; j++)
                    Console.Write("{0} ", num++);
                Console.Write("\n");
                midl--;
            }
        Console.ReadKey();
         }
    }
}
