﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LessonH3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Please enter your 1 number: ");
            string inputA = Console.ReadLine();
            while (!int.TryParse(inputA, out num))
            {
                Console.WriteLine("Invalid. Please, enter a number.");
                inputA = Console.ReadLine();
            }
            int a = Convert.ToInt32(inputA);


            Console.WriteLine("Please enter your 2 number: ");
            string inputB = Console.ReadLine();
            while (!int.TryParse(inputB, out num))
            {
                Console.WriteLine("Invalid. Please, enter a number.");
                inputB = Console.ReadLine();
            }
            int b = Convert.ToInt32(inputB);


            Console.WriteLine("Please enter your 3 number: ");
            string inputC = Console.ReadLine();
            while (!int.TryParse(inputC, out num))
            {
                Console.WriteLine("Invalid. Please, enter a number.");
                inputC = Console.ReadLine();
            }
            int c = Convert.ToInt32(inputC);


     // compare
            int compare;

            if (a == b && a == c && b == c)
            {
                Console.WriteLine("Equal numbers!");
            }
            else if (a > b && a > c)
            {
                compare = a;
                Console.WriteLine("The greatest number is: " + compare);
            }
            else if (b > a && b > c)
            {
               compare = b;
                Console.WriteLine("The greatest number is: " + compare);
            }
            else if (c > a && c > b)
            {
                compare = c;
                Console.WriteLine("The greatest number is: " + compare);
            }
            else if (a == b || a == c || b == c)
            {
                Console.WriteLine("Please enter 3 different numbers. Two biggest numbers are equal!");
            }
            else
                Console.WriteLine("Invalid" );

            Console.ReadKey();

        }
    }
}
