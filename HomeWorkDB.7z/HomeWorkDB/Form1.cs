﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWorkDB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.DataSource = Enum.GetValues(typeof(ComboBox1));
        }

        //Connection string
        string connectionString = "Integrated Security = True; Initial Catalog = NBcSharp; Data Source = wsp6788d";

        //Query string
        string queryString = "SELECT Name, Surname, Age, Gender from dbo.Person";

        int PersonID;

        public enum ComboBox1
        {
            Male,
            Female,
            Unknown,
        }


        private void ButtonShowAll_Click(object sender, EventArgs e)
        {

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                String sql = "Select * from dbo.Person";
                SqlCommand command = new SqlCommand(sql, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();

                try

                {
                    connection.Open();
                    adapter.Fill(dt);
                    dataGridView.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }

        }


        private void Form1_Load(object sender, EventArgs e)
        {
            this.personTableAdapter.Fill(this.nBcSharpDataSet.Person);
        }


        private void ButtonSave_Click(object sender, EventArgs e)
        {

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                var queryInsert = "INSERT INTO Person (Name, Surname, Age, Gender) VALUES('" + textBox1.Text + "', '" + textBox4.Text + "', '" + textBox3.Text + "', '" + comboBox1.Text + "')";

                SqlCommand command = new SqlCommand(queryInsert, connection);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Record Inserted Successfully");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }

        }

        private void ButtonDelet_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                var queryDelete = "Delete from dbo.Person where Name='" + textBox1.Text + "'";

                SqlCommand command = new SqlCommand(queryDelete, connection);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Record deleted successfuly!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }
        }

        private void ButtonUpdate_Click(object sender, EventArgs e)
        {

            using (SqlConnection conn = new SqlConnection(connectionString))
            {

                try

                {
                    string sql = "update dbo.Person set Name=@Name ,Surname=@Surname, Age=@Age, Gender=@Gender where PersonID=@id";
                    SqlCommand cmd = new SqlCommand(sql, conn);

                    conn.Open();
                    cmd.Parameters.AddWithValue("@id", PersonID);
                    cmd.Parameters.AddWithValue("@Name", textBox1.Text);
                    cmd.Parameters.AddWithValue("@Surname", textBox4.Text);
                    cmd.Parameters.AddWithValue("@Age", textBox3.Text);
                    cmd.Parameters.AddWithValue("@Gender", comboBox1.Text);

                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Record updated successfuly!");
                    }
                    else
                    {
                        MessageBox.Show("Please select record to update!");
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }

        }



        private void ButtonSearcByName_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                var querySearchName = "Select * from dbo.Person where Name='" + textBox2.Text + "'";

                SqlCommand command = new SqlCommand(querySearchName, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);

                try

                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }

        }


        private void DataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dataGridView.CurrentRow.Selected = true;
                PersonID = Convert.ToInt32(dataGridView.Rows[e.RowIndex].Cells[0].Value.ToString());
                textBox1.Text = dataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox4.Text = dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBox3.Text = dataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
                comboBox1.Text = dataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
            }
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox1.SelectedItem = ComboBox1.Unknown;
        }
    }
}

