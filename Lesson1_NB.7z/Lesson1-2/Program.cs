using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson1_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your A number: ");
            string inputA = Console.ReadLine();
            int a = Convert.ToInt32(inputA);
            Console.WriteLine("Please enter your B number: ");
            string inputB = Console.ReadLine();
            int b = Convert.ToInt32(inputB);
            int c = a;

            a = b;
            b = c;

            Console.WriteLine("Swapped A = " + a + ", " + "Swapped B = " + b);
            Console.ReadKey();

        }
    }
}

