using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson1_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your 1 number: ");
            string inputA = Console.ReadLine();
            float a = Convert.ToSingle(inputA);
        
            Console.WriteLine("Please enter your 2 number: ");
            string inputB = Console.ReadLine();
            float b = Convert.ToSingle(inputB);
            Console.WriteLine("Please enter your 3 number: ");
            string inputC = Console.ReadLine();
            float c = Convert.ToSingle(inputC);
            Console.WriteLine("Please enter your 4 number: ");
            string inputD = Console.ReadLine();
            float d = Convert.ToSingle(inputD);

            float average = (a + b + c + d) / 4;
            Console.WriteLine("Average = "+average);
            Console.ReadKey();

        }
    }
}
