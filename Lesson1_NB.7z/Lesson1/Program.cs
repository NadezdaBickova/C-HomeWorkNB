using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your Name: ");
            string userName = Console.ReadLine();
            Console.WriteLine("Please enter your Surname: ");
            string userSurname = Console.ReadLine();
            Console.WriteLine("Please enter your number: ");
            var userNumberFirst = Console.ReadLine();
            int num;

            while (!int.TryParse(userNumberFirst, out num)){
                Console.WriteLine("Invalid. Please, enter a number.");
                userNumberFirst = Console.ReadLine();
            }
            Console.WriteLine("Hello, " + userName + " " + userSurname + ". You have entered number " + userNumberFirst + ". Press any key to exit.");
            Console.ReadKey();
        }
    }
}
