using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson1_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your number for multiplication: ");
            var inputA = Console.ReadLine();
            int num;

            while (!int.TryParse(inputA, out num))
            {
                Console.WriteLine("Invalid. Please, enter a number.");
                inputA = Console.ReadLine();
            }

            int a = Convert.ToInt32(inputA);
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("\t\t\t\t\t\t\t\t\t");
                int value = i * a;
                Console.Write("{0} * {1} = {2}\t", i, a, value);
            }
          
            Console.ReadKey();

        }
    }
}
